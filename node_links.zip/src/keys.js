module.exports = {

    database: {
        connectionLimit: 10,
        host: 'localhost',
        user: 'root',
        password: 'qwert!@#',
        database: 'db_links'
    }

};